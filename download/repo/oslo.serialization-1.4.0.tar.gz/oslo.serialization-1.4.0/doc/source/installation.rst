============
Installation
============

At the command line::

    $ pip install oslo.serialization

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv oslo.serialization
    $ pip install oslo.serialization