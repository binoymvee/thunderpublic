====================
 oslo.serialization
====================

An OpenStack library for representing objects in transmittable and
storable formats.

Contents
========

.. toctree::
   :maxdepth: 1

   readme
   installation
   api
   history
   contributing
   history
