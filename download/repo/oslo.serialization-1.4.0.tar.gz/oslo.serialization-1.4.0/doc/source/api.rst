=====
 API
=====

jsonutils
=========

.. automodule:: oslo_serialization.jsonutils
   :members:
