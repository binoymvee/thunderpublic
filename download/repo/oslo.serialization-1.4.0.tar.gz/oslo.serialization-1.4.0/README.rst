====================
 oslo.serialization
====================

oslo.serialization library

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/oslo.serialization
* Source: http://git.openstack.org/cgit/openstack/oslo.serialization
* Bugs: http://bugs.launchpad.net/oslo.serialization
