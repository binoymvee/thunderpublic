==================================================
 oslo.i18n -- Oslo Internationalization Utilities
==================================================

The oslo.i18n library contain utilities for working with
internationalization (i18n) features, especially translation for text
strings in an application or library.

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/oslo.i18n
* Source: http://git.openstack.org/cgit/openstack/oslo.i18n
* Bugs: http://bugs.launchpad.net/oslo.i18n
