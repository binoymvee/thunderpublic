---------------------
Notification Listener
---------------------

.. automodule:: oslo_messaging.notify.listener

.. currentmodule:: oslo_messaging

.. autofunction:: get_notification_listener

.. autoclass:: MessageHandlingServer
   :members:
   :noindex:

.. autofunction:: get_local_context
   :noindex:
