----------------------
Configuration Options
----------------------

.. currentmodule:: oslo_messaging.opts

.. autofunction:: list_opts
