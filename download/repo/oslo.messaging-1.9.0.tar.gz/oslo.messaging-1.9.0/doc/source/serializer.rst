----------
Serializer
----------

.. currentmodule:: oslo_messaging

.. autoclass:: Serializer
   :members:

.. autoclass:: NoOpSerializer
