===========
 timeutils
===========

.. automodule:: oslo_utils.timeutils
   :members:
