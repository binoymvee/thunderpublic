===================================
oslo.utils
===================================

oslo.utils library

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/oslo.utils
* Source: http://git.openstack.org/cgit/openstack/oslo.utils
* Bugs: http://bugs.launchpad.net/oslo.utils
