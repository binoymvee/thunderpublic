=======
 Usage
=======

To use oslo.context in a project::

    from oslo_context import context
