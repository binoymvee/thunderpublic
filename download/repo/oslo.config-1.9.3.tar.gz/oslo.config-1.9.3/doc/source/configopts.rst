--------------------
The ConfigOpts Class
--------------------

.. currentmodule:: oslo_config.cfg

.. autoclass:: ConfigOpts
   :members:
