----------------
Helper Functions
----------------

.. currentmodule:: oslo_config.cfg

.. autofunction:: find_config_files
.. autofunction:: set_defaults
