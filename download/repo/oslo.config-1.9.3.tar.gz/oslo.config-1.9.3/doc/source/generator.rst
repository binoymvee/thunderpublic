---------------------
oslo-config-generator
---------------------

.. automodule:: oslo_config.generator

.. currentmodule:: oslo_config.generator

.. autofunction:: main
.. autofunction:: generate
.. autofunction:: register_cli_opts
