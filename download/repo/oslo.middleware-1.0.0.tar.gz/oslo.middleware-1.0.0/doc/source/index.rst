.. include:: ../../README.rst

Contents
========

.. toctree::
   :maxdepth: 2

   installation
   api
   healthcheck_plugins
   contributing
